# Desi Farming

Portrait, top-down 2D farming game for Android. Pure Kotlin + Canvas, no libraries, no permissions, no network.

Crops: Wheat, Groundnut, Cereals, Sugarcane (each with its own growth time, price and seasons).
Actions: till, sow, water, fertilize, pull weeds, harvest, store in barn, sell.
Seasons: Summer, Monsoon, Autumn, Winter (6 days each, monsoon can bring rain).
Shop: seeds, fertilizer, land plots, tool upgrades (hoe, watering can, sickle), fertile soil, bigger barn.
Quests: a few simple rotating quests with coin rewards. Progress auto-saves.

Before publishing: change applicationId/namespace in app/build.gradle.kts (and the package folder/lines) to your own unique ID.
