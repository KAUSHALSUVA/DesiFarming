# No special rules needed: the app has no reflection and no third-party libraries.
