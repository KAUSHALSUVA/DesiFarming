package com.desifarming.game

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min
import kotlin.random.Random

const val COLS = 4
const val ROWS = 6
const val DAY_LEN = 50f      // seconds per game day
const val SEASON_LEN = 6     // days per season
const val FERT_COST = 15
const val START_PLOTS = 6

/** All game rules and saved state. No drawing code here. */
class FarmGame(private val prefs: SharedPreferences) {

    var coins = 0
    var day = 1
    var dayTime = 0f
    var rainToday = false
    val tiles = Array(COLS * ROWS) { Tile() }
    val seeds = IntArray(4)
    val crops = IntArray(4)
    var fertilizer = 0
    var hoeLv = 1
    var canLv = 1
    var sickleLv = 1
    var soilLv = 0
    var storageLv = 0
    var tool = Tool.HOE
    var seedType = CropType.CEREALS
    var soundOn = true
    var helpShown = false
    val quests = ArrayList<Quest>()
    var pendingLand = -1

    var toastText = ""
    var toastTime = 0f

    /** 0 = ok, 1 = coin, 2 = error */
    var sfx: ((Int) -> Unit)? = null

    init {
        if (!load()) newGame()
    }

    // ------------------------------------------------------------------
    // Basic info
    // ------------------------------------------------------------------

    fun season(): Season = Season.values()[((day - 1) / SEASON_LEN) % 4]
    fun dayInSeason(): Int = ((day - 1) % SEASON_LEN) + 1
    fun year(): Int = (day - 1) / (SEASON_LEN * 4) + 1
    fun capacity(): Int = 30 + 20 * storageLv
    fun stored(): Int = crops.sum()

    fun ownedCount(): Int {
        var n = 0
        for (t in tiles) if (t.owned) n++
        return n
    }

    fun landCost(): Int = 60 + 45 * (ownedCount() - START_PLOTS).coerceAtLeast(0)

    fun toast(msg: String) {
        toastText = msg
        toastTime = 2.4f
    }

    private fun snd(k: Int) {
        sfx?.invoke(k)
    }

    // ------------------------------------------------------------------
    // Time
    // ------------------------------------------------------------------

    fun update(dt: Float, advanceTime: Boolean) {
        if (toastTime > 0f) toastTime -= dt
        if (!advanceTime) return
        dayTime += dt
        if (dayTime >= DAY_LEN) endDay()
    }

    fun endDay() {
        for (t in tiles) {
            if (!t.owned) continue
            val c = t.crop
            if (c != null && t.watered && !t.weeds && t.progress < c.growDays.toFloat()) {
                var g = 1f + soilLv * 0.2f
                if (t.fertilized) g *= 2f
                t.progress = min(c.growDays.toFloat(), t.progress + g)
            }
            t.watered = false
            if (t.tilled && !t.weeds && Random.nextFloat() < 0.12f) t.weeds = true
        }
        val oldSeason = season()
        day++
        dayTime = 0f
        val s = season()
        rainToday = s == Season.MONSOON && Random.nextFloat() < 0.4f
        if (rainToday) {
            for (t in tiles) if (t.owned && t.crop != null) t.watered = true
            toast("It is raining! Crops watered.")
        } else {
            toast("Day ${dayInSeason()} of ${s.label}")
        }
        if (s != oldSeason) toast("${s.label} season has begun!")
        save()
    }

    // ------------------------------------------------------------------
    // Farm actions
    // ------------------------------------------------------------------

    fun area(index: Int, level: Int): List<Int> {
        val r = index / COLS
        val c = index % COLS
        val out = ArrayList<Int>()
        for (dr in -1..1) {
            for (dc in -1..1) {
                val isCenter = dr == 0 && dc == 0
                val isPlus = dr == 0 || dc == 0
                val take = when (level) {
                    1 -> isCenter
                    2 -> isPlus
                    else -> true
                }
                if (!take) continue
                val rr = r + dr
                val cc = c + dc
                if (rr in 0 until ROWS && cc in 0 until COLS) {
                    val i = rr * COLS + cc
                    if (tiles[i].owned) out.add(i)
                }
            }
        }
        return out
    }

    fun tapTile(index: Int, firstTouch: Boolean) {
        val t = tiles[index]
        if (!t.owned) {
            if (!firstTouch) return
            val cost = landCost()
            if (pendingLand == index) {
                if (coins >= cost) {
                    coins -= cost
                    t.owned = true
                    pendingLand = -1
                    toast("New plot bought!")
                    snd(1)
                } else {
                    toast("You need ₹$cost for this plot")
                    snd(2)
                }
            } else {
                pendingLand = index
                toast("Tap again to buy this plot for ₹$cost")
            }
            return
        }
        pendingLand = -1
        when (tool) {
            Tool.HOE -> applyHoe(index, firstTouch)
            Tool.SEED -> applyPlant(index, firstTouch)
            Tool.WATER -> applyWater(index, firstTouch)
            Tool.FERT -> applyFert(index, firstTouch)
            Tool.SICKLE -> applySickle(index, firstTouch)
        }
    }

    private fun applyHoe(index: Int, msg: Boolean) {
        var n = 0
        for (i in area(index, hoeLv)) {
            val t = tiles[i]
            if (!t.tilled && t.crop == null) {
                t.tilled = true
                t.weeds = false
                n++
            }
        }
        if (n > 0) snd(0) else if (msg) toast("Soil is already tilled")
    }

    private fun applyPlant(index: Int, msg: Boolean) {
        val crop = seedType
        val s = season()
        if (s !in crop.seasons) {
            if (msg) toast("${crop.label} grows in ${crop.seasonText()}, not ${s.label}")
            return
        }
        var n = 0
        var noSeeds = false
        for (i in area(index, hoeLv)) {
            val t = tiles[i]
            if (t.tilled && t.crop == null) {
                if (seeds[crop.ordinal] <= 0) {
                    noSeeds = true
                    break
                }
                seeds[crop.ordinal]--
                t.crop = crop
                t.progress = 0f
                t.watered = false
                t.fertilized = false
                n++
            }
        }
        if (n > 0) {
            questEvent(QType.PLANT, null, n)
            snd(0)
        } else if (msg) {
            if (noSeeds || seeds[crop.ordinal] <= 0) toast("No ${crop.label} seeds. Buy them in the Shop")
            else toast("Till the soil first (Hoe)")
        }
    }

    private fun applyWater(index: Int, msg: Boolean) {
        var n = 0
        for (i in area(index, canLv)) {
            val t = tiles[i]
            if (t.crop != null && !t.watered && !t.ripe()) {
                t.watered = true
                n++
            }
        }
        if (n > 0) {
            questEvent(QType.WATER, null, n)
            snd(0)
        } else if (msg) {
            toast("Nothing to water here")
        }
    }

    private fun applyFert(index: Int, msg: Boolean) {
        if (fertilizer <= 0) {
            if (msg) toast("No fertilizer. Buy some in the Shop")
            return
        }
        var n = 0
        for (i in area(index, canLv)) {
            if (fertilizer <= 0) break
            val t = tiles[i]
            if (t.crop != null && !t.fertilized && !t.ripe()) {
                t.fertilized = true
                fertilizer--
                n++
            }
        }
        if (n > 0) snd(0) else if (msg) toast("Plant a crop first, then fertilize")
    }

    private fun applySickle(index: Int, msg: Boolean) {
        var weeds = 0
        var harvested = 0
        var full = false
        for (i in area(index, sickleLv)) {
            val t = tiles[i]
            val c = t.crop
            if (t.weeds) {
                t.weeds = false
                weeds++
            } else if (c != null && t.ripe()) {
                val y = 2 + (if (t.fertilized) 1 else 0)
                if (stored() + y > capacity()) {
                    full = true
                    continue
                }
                crops[c.ordinal] += y
                harvested += y
                t.crop = null
                t.progress = 0f
                t.watered = false
                t.fertilized = false
                t.tilled = false
                questEvent(QType.HARVEST_CROP, c, y)
            }
        }
        if (weeds > 0) questEvent(QType.WEED, null, weeds)
        if (weeds > 0 || harvested > 0) {
            snd(1)
            if (harvested > 0) toast("Harvested $harvested")
        }
        if (full) {
            toast("Barn is full! Sell crops or upgrade the barn")
            snd(2)
        } else if (weeds == 0 && harvested == 0 && msg) {
            toast("No weeds or ripe crops here")
        }
    }

    // ------------------------------------------------------------------
    // Economy
    // ------------------------------------------------------------------

    fun sell(i: Int, all: Boolean) {
        val n = if (all) crops[i] else min(1, crops[i])
        if (n <= 0) return
        val gain = n * CropType.values()[i].sellPrice
        crops[i] -= n
        coins += gain
        questEvent(QType.EARN, null, gain)
        snd(1)
    }

    fun buySeeds(i: Int, n: Int) {
        val cost = CropType.values()[i].seedCost * n
        if (coins >= cost) {
            coins -= cost
            seeds[i] += n
            snd(1)
        } else {
            toast("Not enough coins")
            snd(2)
        }
    }

    fun buyFert(n: Int) {
        val cost = FERT_COST * n
        if (coins >= cost) {
            coins -= cost
            fertilizer += n
            snd(1)
        } else {
            toast("Not enough coins")
            snd(2)
        }
    }

    fun buyNextLand() {
        var best = -1
        var bestD = 1000f
        for (i in tiles.indices) {
            if (tiles[i].owned) continue
            val r = (i / COLS).toFloat() - 2.5f
            val c = (i % COLS).toFloat() - 1.5f
            val d = r * r + c * c
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        if (best < 0) {
            toast("You own all the land!")
            return
        }
        val cost = landCost()
        if (coins >= cost) {
            coins -= cost
            tiles[best].owned = true
            toast("New plot bought!")
            snd(1)
        } else {
            toast("You need ₹$cost")
            snd(2)
        }
    }

    // Upgrade kinds: 0 hoe, 1 watering can, 2 sickle, 3 soil, 4 barn
    fun level(kind: Int): Int = when (kind) {
        0 -> hoeLv
        1 -> canLv
        2 -> sickleLv
        3 -> soilLv
        else -> storageLv
    }

    fun maxLevel(kind: Int): Int = if (kind == 4) 5 else 3

    fun upgradeCost(kind: Int): Int = when (kind) {
        0, 1, 2 -> if (level(kind) <= 1) 150 else 400
        3 -> intArrayOf(200, 500, 1000)[soilLv.coerceIn(0, 2)]
        else -> 120 * (storageLv + 1)
    }

    fun buyUpgrade(kind: Int) {
        if (level(kind) >= maxLevel(kind)) return
        val cost = upgradeCost(kind)
        if (coins < cost) {
            toast("Not enough coins")
            snd(2)
            return
        }
        coins -= cost
        when (kind) {
            0 -> hoeLv++
            1 -> canLv++
            2 -> sickleLv++
            3 -> soilLv++
            else -> storageLv++
        }
        snd(1)
        toast("Upgraded!")
    }

    // ------------------------------------------------------------------
    // Quests
    // ------------------------------------------------------------------

    fun questEvent(type: QType, crop: CropType?, amount: Int) {
        for (q in quests) {
            if (q.done()) continue
            val match = when (q.type) {
                QType.HARVEST -> type == QType.HARVEST_CROP || type == QType.HARVEST
                QType.HARVEST_CROP -> type == QType.HARVEST_CROP && q.crop == crop
                else -> q.type == type
            }
            if (match) q.progress = min(q.target, q.progress + amount)
        }
    }

    private fun newQuest(): Quest {
        val scale = 1 + day / 10
        return when (Random.nextInt(6)) {
            0 -> Quest(QType.HARVEST, null, 6 * scale, 0, 60 * scale)
            1 -> {
                val s = season()
                val options = CropType.values().filter { s in it.seasons }
                val c = options[Random.nextInt(options.size)]
                Quest(QType.HARVEST_CROP, c, 4 * scale, 0, c.sellPrice * 4 * scale + 20)
            }
            2 -> Quest(QType.PLANT, null, 5 * scale, 0, 40 * scale)
            3 -> Quest(QType.WATER, null, 8 * scale, 0, 45 * scale)
            4 -> Quest(QType.WEED, null, 3 * scale, 0, 35 * scale)
            else -> Quest(QType.EARN, null, 150 * scale, 0, 75 * scale)
        }
    }

    fun claimQuest(i: Int) {
        if (i !in quests.indices) return
        val q = quests[i]
        if (!q.done()) return
        coins += q.reward
        quests[i] = newQuest()
        toast("Quest reward: ₹${q.reward}")
        snd(1)
    }

    // ------------------------------------------------------------------
    // Save / load
    // ------------------------------------------------------------------

    private fun newGame() {
        coins = 120
        day = 1
        dayTime = 0f
        rainToday = false
        for (t in tiles) t.reset()
        for (r in 2..4) for (c in 1..2) tiles[r * COLS + c].owned = true
        seeds[0] = 4
        seeds[1] = 4
        seeds[2] = 6
        seeds[3] = 1
        for (i in crops.indices) crops[i] = 0
        fertilizer = 3
        hoeLv = 1
        canLv = 1
        sickleLv = 1
        soilLv = 0
        storageLv = 0
        quests.clear()
        for (k in 0 until 3) quests.add(newQuest())
    }

    fun save() {
        try {
            val o = JSONObject()
            o.put("coins", coins)
            o.put("day", day)
            o.put("dayTime", dayTime.toDouble())
            o.put("fert", fertilizer)
            o.put("hoe", hoeLv)
            o.put("can", canLv)
            o.put("sickle", sickleLv)
            o.put("soil", soilLv)
            o.put("storage", storageLv)
            o.put("sound", soundOn)
            o.put("help", helpShown)
            o.put("seedType", seedType.ordinal)
            val sa = JSONArray()
            val ca = JSONArray()
            for (i in seeds.indices) {
                sa.put(seeds[i])
                ca.put(crops[i])
            }
            o.put("seeds", sa)
            o.put("crops", ca)
            val ta = JSONArray()
            for (t in tiles) {
                val cid = t.crop?.ordinal ?: -1
                ta.put(
                    "${if (t.owned) 1 else 0},${if (t.tilled) 1 else 0},$cid,${t.progress}," +
                            "${if (t.watered) 1 else 0},${if (t.fertilized) 1 else 0},${if (t.weeds) 1 else 0}"
                )
            }
            o.put("tiles", ta)
            val qa = JSONArray()
            for (q in quests) {
                val qo = JSONObject()
                qo.put("type", q.type.name)
                qo.put("crop", q.crop?.ordinal ?: -1)
                qo.put("target", q.target)
                qo.put("progress", q.progress)
                qo.put("reward", q.reward)
                qa.put(qo)
            }
            o.put("quests", qa)
            prefs.edit().putString("save", o.toString()).apply()
        } catch (e: Exception) {
            // Saving is best effort.
        }
    }

    private fun load(): Boolean {
        val s = prefs.getString("save", null) ?: return false
        return try {
            val o = JSONObject(s)
            coins = o.getInt("coins")
            day = o.getInt("day")
            dayTime = o.getDouble("dayTime").toFloat()
            fertilizer = o.getInt("fert")
            hoeLv = o.getInt("hoe")
            canLv = o.getInt("can")
            sickleLv = o.getInt("sickle")
            soilLv = o.getInt("soil")
            storageLv = o.getInt("storage")
            soundOn = o.optBoolean("sound", true)
            helpShown = o.optBoolean("help", false)
            seedType = CropType.values()[o.optInt("seedType", 2).coerceIn(0, 3)]
            val sa = o.getJSONArray("seeds")
            val ca = o.getJSONArray("crops")
            for (i in seeds.indices) {
                seeds[i] = sa.getInt(i)
                crops[i] = ca.getInt(i)
            }
            val ta = o.getJSONArray("tiles")
            for (i in tiles.indices) {
                val p = ta.getString(i).split(",")
                val t = tiles[i]
                t.owned = p[0] == "1"
                t.tilled = p[1] == "1"
                val cid = p[2].toInt()
                t.crop = if (cid in 0..3) CropType.values()[cid] else null
                t.progress = p[3].toFloat()
                t.watered = p[4] == "1"
                t.fertilized = p[5] == "1"
                t.weeds = p[6] == "1"
            }
            quests.clear()
            val qa = o.getJSONArray("quests")
            for (i in 0 until qa.length()) {
                val qo = qa.getJSONObject(i)
                val cid = qo.getInt("crop")
                quests.add(
                    Quest(
                        QType.valueOf(qo.getString("type")),
                        if (cid in 0..3) CropType.values()[cid] else null,
                        qo.getInt("target"),
                        qo.getInt("progress"),
                        qo.getInt("reward")
                    )
                )
            }
            while (quests.size < 3) quests.add(newQuest())
            true
        } catch (e: Exception) {
            false
        }
    }
}
