package com.desifarming.game

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private enum class PanelKind { SHOP, BARN, QUESTS, SEEDS, HELP }

private class Btn(val label: String, val enabled: Boolean, val action: () -> Unit)

private class Row(val title: String, val sub: String, val color: Int, val buttons: List<Btn>)

private class Hit(val rect: RectF, val action: () -> Unit)

/**
 * Draws the farm and handles all touch input. Sizes are relative to the screen width
 * (u = width / 1080) so the game scales to any phone in portrait.
 */
@SuppressLint("ViewConstructor")
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private val lock = Any()
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var surfaceReady = false

    private val game = FarmGame(context.getSharedPreferences("desi_farming", Context.MODE_PRIVATE))
    private var tone: ToneGenerator? = null

    // screen geometry
    private var w = 0f
    private var h = 0f
    private var u = 1f
    private var hudH = 0f
    private var farmTop = 0f
    private var farmBottom = 0f
    private var toolTop = 0f
    private var menuTop = 0f
    private var cell = 0f
    private var gridX = 0f
    private var gridY = 0f

    // ui state
    private var panel: PanelKind? = null
    private var shopTab = 0
    private var clock = 0f
    private val hits = ArrayList<Hit>()
    private var pressedRect: RectF? = null
    private var touchOnFarm = false
    private var lastTile = -1

    // weather particles
    private val wx = FloatArray(45) { Random.nextFloat() }
    private val wy = FloatArray(45) { Random.nextFloat() }

    // paints
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val path = Path()
    private val rect = RectF()

    init {
        holder.addCallback(this)
        isFocusable = true
        game.sfx = { k -> beep(k) }
        if (!game.helpShown) {
            panel = PanelKind.HELP
            game.helpShown = true
        }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================

    fun resume() {
        if (surfaceReady) startThread()
    }

    fun pause() {
        stopThread()
        synchronized(lock) { game.save() }
        try {
            tone?.release()
        } catch (_: Exception) {
        }
        tone = null
    }

    private fun startThread() {
        if (running) return
        running = true
        thread = Thread(this, "GameLoop").also { it.start() }
    }

    private fun stopThread() {
        running = false
        try {
            thread?.join(500)
        } catch (_: InterruptedException) {
        }
        thread = null
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        startThread()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        synchronized(lock) {
            w = width.toFloat()
            h = height.toFloat()
            computeLayout()
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        stopThread()
        synchronized(lock) { game.save() }
    }

    private fun computeLayout() {
        u = w / 1080f
        hudH = 190f * u
        val menuH = 96f * u
        val toolH = 150f * u
        menuTop = h - 28f * u - menuH
        toolTop = menuTop - 12f * u - toolH
        farmTop = hudH + 8f * u
        farmBottom = toolTop - 10f * u
        val fh = farmBottom - farmTop
        cell = min(w * 0.98f / COLS, fh / ROWS)
        gridX = (w - cell * COLS) / 2f
        gridY = farmTop + (fh - cell * ROWS) / 2f
    }

    // =====================================================================
    // Game loop
    // =====================================================================

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            var dt = (now - last) / 1_000_000_000f
            last = now
            if (dt > 0.05f) dt = 0.05f

            val canvas = try {
                holder.lockCanvas()
            } catch (_: Exception) {
                null
            }
            if (canvas != null) {
                try {
                    synchronized(lock) {
                        if (w > 0f) {
                            clock += dt
                            game.update(dt, panel == null)
                            drawFrame(canvas)
                        }
                    }
                } finally {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (_: Exception) {
                    }
                }
            }

            val spent = (System.nanoTime() - now) / 1_000_000L
            val wait = 16L - spent
            if (wait > 0) {
                try {
                    Thread.sleep(wait)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun beep(k: Int) {
        if (!game.soundOn) return
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 40)
            when (k) {
                0 -> tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
                1 -> tone?.startTone(ToneGenerator.TONE_PROP_ACK, 90)
                else -> tone?.startTone(ToneGenerator.TONE_PROP_NACK, 120)
            }
        } catch (_: Exception) {
        }
    }

    // =====================================================================
    // Touch
    // =====================================================================

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        synchronized(lock) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pressedRect = null
                    touchOnFarm = false
                    lastTile = -1
                    val hit = findHit(event.x, event.y)
                    if (hit != null) {
                        pressedRect = RectF(hit.rect)
                    } else if (panel == null) {
                        val ti = tileAt(event.x, event.y)
                        if (ti >= 0) {
                            touchOnFarm = true
                            lastTile = ti
                            game.tapTile(ti, true)
                        }
                    }
                }

                MotionEvent.ACTION_MOVE -> {
                    if (touchOnFarm && panel == null) {
                        val ti = tileAt(event.x, event.y)
                        if (ti >= 0 && ti != lastTile) {
                            lastTile = ti
                            game.tapTile(ti, false)
                        }
                    }
                }

                MotionEvent.ACTION_UP -> {
                    val pr = pressedRect
                    if (!touchOnFarm && pr != null) {
                        val hit = findHit(event.x, event.y)
                        if (hit != null && hit.rect == pr) hit.action()
                    }
                    pressedRect = null
                    touchOnFarm = false
                }

                MotionEvent.ACTION_CANCEL -> {
                    pressedRect = null
                    touchOnFarm = false
                }

                else -> Unit
            }
        }
        return true
    }

    private fun findHit(x: Float, y: Float): Hit? {
        for (i in hits.indices.reversed()) {
            val hit = hits[i]
            if (hit.rect.contains(x, y)) return hit
        }
        return null
    }

    private fun tileAt(x: Float, y: Float): Int {
        val cx = ((x - gridX) / cell).toInt()
        val cy = ((y - gridY) / cell).toInt()
        if (x < gridX || y < gridY) return -1
        if (cx !in 0 until COLS || cy !in 0 until ROWS) return -1
        return cy * COLS + cx
    }

    private fun addHit(l: Float, t: Float, r: Float, b: Float, action: () -> Unit) {
        hits.add(Hit(RectF(l, t, r, b), action))
    }

    // =====================================================================
    // Small drawing helpers
    // =====================================================================

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
    }

    private fun stroke(color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.color = color
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
    }

    private fun txt(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        align: Paint.Align = Paint.Align.LEFT, maxW: Float = 0f
    ) {
        textPaint.textSize = size
        textPaint.color = color
        textPaint.textAlign = align
        if (maxW > 0f) {
            var sz = size
            while (textPaint.measureText(s) > maxW && sz > 12f * u) {
                sz -= 1.5f * u
                textPaint.textSize = sz
            }
        }
        c.drawText(s, x, y, textPaint)
    }

    private fun roundRect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        fill(color)
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
    }

    private fun cropColor(type: CropType): Int = when (type) {
        CropType.WHEAT -> 0xFFE6B840.toInt()
        CropType.GROUNDNUT -> 0xFFB5793A.toInt()
        CropType.CEREALS -> 0xFF9CCC4A.toInt()
        CropType.SUGARCANE -> 0xFF8E5BB5.toInt()
    }

    // =====================================================================
    // Frame
    // =====================================================================

    private fun drawFrame(c: Canvas) {
        hits.clear()
        val season = game.season()

        // ground
        fill(
            when (season) {
                Season.SUMMER -> 0xFF8BC34A.toInt()
                Season.MONSOON -> 0xFF4E9F5B.toInt()
                Season.AUTUMN -> 0xFFB9B05A.toInt()
                Season.WINTER -> 0xFFD3E6DF.toInt()
            }
        )
        c.drawRect(0f, 0f, w, h, paint)

        drawTiles(c, season)
        drawWeather(c, season)
        drawNight(c)
        drawHud(c, season)
        drawToolbar(c)
        drawMenu(c)
        drawToast(c)
        if (panel != null) drawPanel(c)
    }

    // ---------------------------------------------------------------------
    // Farm tiles
    // ---------------------------------------------------------------------

    private fun drawTiles(c: Canvas, season: Season) {
        val grass = when (season) {
            Season.SUMMER -> 0xFF9CCC65.toInt()
            Season.MONSOON -> 0xFF66BB6A.toInt()
            Season.AUTUMN -> 0xFFCDC46A.toInt()
            Season.WINTER -> 0xFFE8F3EE.toInt()
        }
        for (i in 0 until COLS * ROWS) {
            val t = game.tiles[i]
            val col = i % COLS
            val row = i / COLS
            val x = gridX + col * cell
            val y = gridY + row * cell
            val pad = cell * 0.04f
            val rr = cell * 0.1f

            if (!t.owned) {
                roundRect(c, x + pad, y + pad, x + cell - pad, y + cell - pad, rr, 0x33000000)
                stroke(0xFF8D6E63.toInt(), cell * 0.03f)
                c.drawLine(x + cell * 0.12f, y + cell * 0.36f, x + cell * 0.88f, y + cell * 0.36f, paint)
                c.drawLine(x + cell * 0.12f, y + cell * 0.62f, x + cell * 0.88f, y + cell * 0.62f, paint)
                for (k in 0..3) {
                    val px = x + cell * (0.14f + 0.24f * k)
                    c.drawLine(px, y + cell * 0.28f, px, y + cell * 0.7f, paint)
                }
                txt(c, "₹${game.landCost()}", x + cell / 2f, y + cell * 0.9f, cell * 0.17f, Color.WHITE, Paint.Align.CENTER)
                if (game.pendingLand == i) {
                    stroke(0xFFFFEB3B.toInt(), cell * 0.04f)
                    rect.set(x + pad, y + pad, x + cell - pad, y + cell - pad)
                    c.drawRoundRect(rect, rr, rr, paint)
                }
                continue
            }

            val base = when {
                !t.tilled -> grass
                t.watered -> 0xFF5A3921.toInt()
                else -> 0xFF8D5A32.toInt()
            }
            roundRect(c, x + pad, y + pad, x + cell - pad, y + cell - pad, rr, base)

            if (t.tilled) {
                stroke(0x33000000, cell * 0.025f)
                for (k in 1..3) {
                    val ly = y + cell * (0.2f + 0.2f * k)
                    c.drawLine(x + cell * 0.12f, ly, x + cell * 0.88f, ly, paint)
                }
                if (t.watered) {
                    fill(0x552196F3)
                    rect.set(x + pad, y + pad, x + cell - pad, y + cell - pad)
                    c.drawRoundRect(rect, rr, rr, paint)
                }
            }

            val crop = t.crop
            if (crop != null) {
                val ratio = t.progress / crop.growDays.toFloat()
                val stage = when {
                    ratio >= 1f -> 4
                    ratio >= 0.67f -> 3
                    ratio >= 0.34f -> 2
                    ratio > 0f -> 1
                    else -> 0
                }
                drawCrop(c, x + cell / 2f, y + cell / 2f, cell, crop, stage)
                if (stage == 4) {
                    val pulse = 0.8f + 0.2f * sin(clock * 6f)
                    fill(0xFFFFD54F.toInt())
                    c.drawCircle(x + cell * 0.82f, y + cell * 0.2f, cell * 0.09f * pulse, paint)
                    txt(c, "!", x + cell * 0.82f, y + cell * 0.255f, cell * 0.14f, 0xFF6D4C41.toInt(), Paint.Align.CENTER)
                }
                if (t.fertilized) {
                    fill(Color.WHITE)
                    c.drawCircle(x + cell * 0.16f, y + cell * 0.84f, cell * 0.03f, paint)
                    c.drawCircle(x + cell * 0.24f, y + cell * 0.88f, cell * 0.03f, paint)
                    c.drawCircle(x + cell * 0.2f, y + cell * 0.78f, cell * 0.03f, paint)
                }
            }

            if (t.weeds) {
                stroke(0xFF2E7D32.toInt(), cell * 0.04f)
                for (k in 0..4) {
                    val bx = x + cell * (0.2f + 0.15f * k)
                    val by = y + cell * 0.9f
                    c.drawLine(bx, by, bx - cell * 0.05f, by - cell * 0.2f, paint)
                    c.drawLine(bx, by, bx + cell * 0.06f, by - cell * 0.16f, paint)
                }
            }
        }
        fill(Color.WHITE)
    }

    private fun drawCrop(c: Canvas, cx: Float, cy: Float, s: Float, type: CropType, stage: Int) {
        val baseY = cy + s * 0.3f
        if (stage == 0) {
            fill(0xFF4E342E.toInt())
            c.drawCircle(cx - s * 0.15f, baseY - s * 0.05f, s * 0.035f, paint)
            c.drawCircle(cx, baseY - s * 0.12f, s * 0.035f, paint)
            c.drawCircle(cx + s * 0.15f, baseY - s * 0.05f, s * 0.035f, paint)
            return
        }
        val grow = when (stage) {
            1 -> 0.35f
            2 -> 0.65f
            3 -> 0.85f
            else -> 1f
        }
        val ripe = stage == 4
        val green = 0xFF43A047.toInt()
        when (type) {
            CropType.WHEAT -> {
                for (k in -1..1) {
                    val x = cx + k * s * 0.2f
                    val top = baseY - s * 0.5f * grow
                    stroke(if (ripe) 0xFFC9A227.toInt() else green, s * 0.04f)
                    c.drawLine(x, baseY, x, top, paint)
                    if (ripe) {
                        fill(0xFFE6B840.toInt())
                        rect.set(x - s * 0.05f, top - s * 0.12f, x + s * 0.05f, top + s * 0.08f)
                        c.drawOval(rect, paint)
                    } else {
                        fill(green)
                        c.drawCircle(x, top, s * 0.045f, paint)
                    }
                }
            }

            CropType.GROUNDNUT -> {
                val r = s * 0.2f * grow
                fill(0xFF2E7D32.toInt())
                c.drawCircle(cx - r * 0.7f, baseY - r, r, paint)
                c.drawCircle(cx + r * 0.7f, baseY - r, r, paint)
                fill(green)
                c.drawCircle(cx, baseY - r * 1.5f, r * 1.1f, paint)
                if (ripe) {
                    fill(0xFFD7A86E.toInt())
                    for (k in -1..1) {
                        rect.set(cx + k * s * 0.17f - s * 0.05f, baseY - s * 0.04f, cx + k * s * 0.17f + s * 0.05f, baseY + s * 0.06f)
                        c.drawOval(rect, paint)
                    }
                }
            }

            CropType.CEREALS -> {
                for (k in -1..1) {
                    val x = cx + k * s * 0.22f
                    val top = baseY - s * 0.55f * grow
                    stroke(green, s * 0.045f)
                    c.drawLine(x, baseY, x, top, paint)
                    c.drawLine(x, baseY - s * 0.15f * grow, x + s * 0.12f, baseY - s * 0.28f * grow, paint)
                    if (ripe) {
                        fill(0xFFD9A441.toInt())
                        rect.set(x - s * 0.07f, top - s * 0.14f, x + s * 0.07f, top + s * 0.06f)
                        c.drawOval(rect, paint)
                    } else {
                        fill(0xFF9CCC4A.toInt())
                        c.drawCircle(x, top, s * 0.05f, paint)
                    }
                }
            }

            CropType.SUGARCANE -> {
                for (k in -1..1) {
                    val x = cx + k * s * 0.17f
                    val top = baseY - s * 0.62f * grow
                    stroke(if (ripe) 0xFF7B3FA0.toInt() else 0xFF7CB342.toInt(), s * 0.07f)
                    c.drawLine(x, baseY, x, top, paint)
                    stroke(0x55FFFFFF, s * 0.02f)
                    var ny = baseY - s * 0.14f
                    while (ny > top) {
                        c.drawLine(x - s * 0.04f, ny, x + s * 0.04f, ny, paint)
                        ny -= s * 0.14f
                    }
                    stroke(green, s * 0.035f)
                    c.drawLine(x, top, x - s * 0.1f, top - s * 0.08f, paint)
                    c.drawLine(x, top, x + s * 0.1f, top - s * 0.08f, paint)
                }
            }
        }
        fill(Color.WHITE)
    }

    // ---------------------------------------------------------------------
    // Weather, night
    // ---------------------------------------------------------------------

    private fun drawWeather(c: Canvas, season: Season) {
        val rain = season == Season.MONSOON && game.rainToday
        val leaves = season == Season.AUTUMN
        val snow = season == Season.WINTER
        if (!rain && !leaves && !snow) return
        for (i in wx.indices) {
            val speed = if (rain) 1.4f else if (snow) 0.07f else 0.09f
            val fy = (wy[i] + clock * speed * (0.7f + (i % 3) * 0.2f)) % 1f
            val x = (wx[i] * w + sin(clock * 0.9f + i) * 22f * u + w) % w
            val y = fy * h
            if (rain) {
                stroke(0x99B3E5FC.toInt(), 3f * u)
                c.drawLine(x, y, x - 6f * u, y + 34f * u, paint)
            } else if (snow) {
                fill(0xCCFFFFFF.toInt())
                c.drawCircle(x, y, 6f * u, paint)
            } else {
                fill(0xCCE67E22.toInt())
                c.drawCircle(x, y, 8f * u, paint)
            }
        }
        fill(Color.WHITE)
    }

    private fun drawNight(c: Canvas) {
        val f = game.dayTime / DAY_LEN
        if (f > 0.72f) {
            val a = ((f - 0.72f) / 0.28f * 120f).toInt().coerceIn(0, 120)
            fill(Color.argb(a, 10, 15, 50))
            c.drawRect(0f, 0f, w, h, paint)
        }
    }

    // ---------------------------------------------------------------------
    // HUD, toolbar, menu, toast
    // ---------------------------------------------------------------------

    private fun drawHud(c: Canvas, season: Season) {
        fill(0xD91B2A1E.toInt())
        c.drawRect(0f, 0f, w, hudH, paint)
        fill(0xFF33443A.toInt())
        c.drawRect(0f, hudH - 10f * u, w, hudH, paint)
        fill(0xFFFFC107.toInt())
        c.drawRect(0f, hudH - 10f * u, w * (game.dayTime / DAY_LEN).coerceIn(0f, 1f), hudH, paint)

        fill(0xFFFFC107.toInt())
        c.drawCircle(52f * u, 92f * u, 26f * u, paint)
        txt(c, "₹", 52f * u, 103f * u, 32f * u, 0xFF6D4C41.toInt(), Paint.Align.CENTER)
        txt(c, "${game.coins}", 94f * u, 108f * u, 58f * u, Color.WHITE)
        txt(c, "Barn ${game.stored()}/${game.capacity()}", 94f * u, 152f * u, 30f * u, 0xFFB7D7B0.toInt())

        val sc = when (season) {
            Season.SUMMER -> 0xFFFFB74D.toInt()
            Season.MONSOON -> 0xFF4FC3F7.toInt()
            Season.AUTUMN -> 0xFFFF8A65.toInt()
            Season.WINTER -> 0xFFE1F5FE.toInt()
        }
        val sName = if (game.rainToday) season.label + " (rain)" else season.label
        txt(c, sName, w - 28f * u, 100f * u, 48f * u, sc, Paint.Align.RIGHT)
        txt(
            c, "Day ${game.dayInSeason()}/$SEASON_LEN  Year ${game.year()}",
            w - 28f * u, 150f * u, 30f * u, 0xFFD0E8CC.toInt(), Paint.Align.RIGHT
        )
    }

    private fun drawToolIcon(c: Canvas, tool: Tool, cx: Float, cy: Float, r: Float) {
        when (tool) {
            Tool.HOE -> {
                stroke(0xFF8D6E63.toInt(), r * 0.18f)
                c.drawLine(cx - r * 0.7f, cy + r * 0.8f, cx + r * 0.5f, cy - r * 0.7f, paint)
                fill(0xFFB0BEC5.toInt())
                path.reset()
                path.moveTo(cx + r * 0.15f, cy - r * 0.95f)
                path.lineTo(cx + r * 0.95f, cy - r * 0.45f)
                path.lineTo(cx + r * 0.6f, cy - r * 0.1f)
                path.close()
                c.drawPath(path, paint)
            }

            Tool.SEED -> {
                roundRect(c, cx - r * 0.6f, cy - r * 0.8f, cx + r * 0.6f, cy + r * 0.8f, r * 0.2f, cropColor(game.seedType))
                fill(Color.WHITE)
                c.drawCircle(cx, cy, r * 0.28f, paint)
            }

            Tool.WATER -> {
                fill(0xFF42A5F5.toInt())
                path.reset()
                path.moveTo(cx, cy - r)
                path.quadTo(cx + r * 0.95f, cy + r * 0.1f, cx, cy + r * 0.9f)
                path.quadTo(cx - r * 0.95f, cy + r * 0.1f, cx, cy - r)
                path.close()
                c.drawPath(path, paint)
            }

            Tool.FERT -> {
                roundRect(c, cx - r * 0.65f, cy - r * 0.5f, cx + r * 0.65f, cy + r * 0.85f, r * 0.25f, 0xFFD7B98E.toInt())
                roundRect(c, cx - r * 0.4f, cy - r * 0.85f, cx + r * 0.4f, cy - r * 0.45f, r * 0.12f, 0xFF8D6E63.toInt())
                fill(Color.WHITE)
                c.drawCircle(cx - r * 0.2f, cy + r * 0.2f, r * 0.1f, paint)
                c.drawCircle(cx + r * 0.2f, cy + r * 0.4f, r * 0.1f, paint)
            }

            Tool.SICKLE -> {
                stroke(0xFFCFD8DC.toInt(), r * 0.22f)
                rect.set(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.7f, cy + r * 0.7f)
                c.drawArc(rect, 200f, 200f, false, paint)
                stroke(0xFF8D6E63.toInt(), r * 0.22f)
                c.drawLine(cx + r * 0.5f, cy + r * 0.1f, cx + r * 0.9f, cy + r * 0.9f, paint)
            }
        }
        fill(Color.WHITE)
    }

    private fun drawToolbar(c: Canvas) {
        val tools = Tool.values()
        val margin = 14f * u
        val gap = 10f * u
        val bw = (w - 2f * margin - gap * (tools.size - 1)) / tools.size
        val bh = menuTop - 12f * u - toolTop
        for (i in tools.indices) {
            val tl = tools[i]
            val l = margin + i * (bw + gap)
            val sel = game.tool == tl
            roundRect(c, l, toolTop, l + bw, toolTop + bh, 22f * u, if (sel) 0xFFFFF59D.toInt() else 0xE6314A36.toInt())
            if (sel) {
                stroke(0xFFFFC107.toInt(), 5f * u)
                rect.set(l, toolTop, l + bw, toolTop + bh)
                c.drawRoundRect(rect, 22f * u, 22f * u, paint)
            }
            drawToolIcon(c, tl, l + bw / 2f, toolTop + bh * 0.38f, 36f * u)
            val labelColor = if (sel) 0xFF3E2723.toInt() else Color.WHITE
            txt(c, tl.label, l + bw / 2f, toolTop + bh * 0.9f, 28f * u, labelColor, Paint.Align.CENTER, bw - 10f * u)

            // count badges
            val badge = when (tl) {
                Tool.SEED -> game.seeds[game.seedType.ordinal]
                Tool.FERT -> game.fertilizer
                else -> -1
            }
            if (badge >= 0) {
                fill(0xFFE53935.toInt())
                c.drawCircle(l + bw - 24f * u, toolTop + 26f * u, 22f * u, paint)
                txt(c, "$badge", l + bw - 24f * u, toolTop + 36f * u, 26f * u, Color.WHITE, Paint.Align.CENTER, 36f * u)
            }

            if (panel == null) {
                addHit(l, toolTop, l + bw, toolTop + bh) { selectTool(tl) }
            }
        }
    }

    private fun drawMenu(c: Canvas) {
        val labels = listOf("Shop", "Barn", "Quests", "Help", if (game.soundOn) "Sound" else "Muted", "Next Day")
        val margin = 14f * u
        val gap = 8f * u
        val bw = (w - 2f * margin - gap * (labels.size - 1)) / labels.size
        val bh = 96f * u
        val anyDone = game.quests.any { it.done() }
        for (i in labels.indices) {
            val l = margin + i * (bw + gap)
            val col = when (i) {
                0 -> 0xFF2E8B57.toInt()
                1 -> 0xFF8D6E63.toInt()
                2 -> 0xFF5C6BC0.toInt()
                3 -> 0xFF607D8B.toInt()
                4 -> 0xFF607D8B.toInt()
                else -> 0xFF455A64.toInt()
            }
            roundRect(c, l, menuTop, l + bw, menuTop + bh, 20f * u, col)
            txt(c, labels[i], l + bw / 2f, menuTop + bh * 0.64f, 29f * u, Color.WHITE, Paint.Align.CENTER, bw - 8f * u)
            if (i == 2 && anyDone) {
                fill(0xFFFFC107.toInt())
                c.drawCircle(l + bw - 14f * u, menuTop + 14f * u, 12f * u, paint)
            }
            if (panel == null) {
                val idx = i
                addHit(l, menuTop, l + bw, menuTop + bh) { menuAction(idx) }
            }
        }
    }

    private fun selectTool(tl: Tool) {
        game.tool = tl
        game.pendingLand = -1
        if (tl == Tool.SEED) {
            panel = PanelKind.SEEDS
        }
    }

    private fun menuAction(idx: Int) {
        when (idx) {
            0 -> panel = PanelKind.SHOP
            1 -> panel = PanelKind.BARN
            2 -> panel = PanelKind.QUESTS
            3 -> panel = PanelKind.HELP
            4 -> game.soundOn = !game.soundOn
            else -> game.endDay()
        }
    }

    private fun drawToast(c: Canvas) {
        if (game.toastTime <= 0f || game.toastText.isEmpty()) return
        val a = (min(1f, game.toastTime / 0.6f) * 235f).toInt().coerceIn(0, 255)
        val bw = w * 0.92f
        val bh = 84f * u
        val l = (w - bw) / 2f
        val t = farmBottom - bh - 6f * u
        roundRect(c, l, t, l + bw, t + bh, 24f * u, Color.argb(a, 30, 30, 30))
        txt(c, game.toastText, w / 2f, t + bh * 0.64f, 34f * u, Color.argb(a, 255, 255, 255), Paint.Align.CENTER, bw - 30f * u)
    }

    // =====================================================================
    // Panels (shop, barn, quests, seeds, help)
    // =====================================================================

    private fun drawPanel(c: Canvas) {
        val kind = panel ?: return
        fill(0xAA000000.toInt())
        c.drawRect(0f, 0f, w, h, paint)
        addHit(0f, 0f, w, h) { panel = null }

        var title = ""
        var rows: List<Row> = emptyList()
        when (kind) {
            PanelKind.SHOP -> {
                title = "Shop"
                rows = shopRows()
            }

            PanelKind.BARN -> {
                title = "Barn  ${game.stored()}/${game.capacity()}"
                rows = barnRows()
            }

            PanelKind.QUESTS -> {
                title = "Quests"
                rows = questRows()
            }

            PanelKind.SEEDS -> {
                title = "Choose seed  (${game.season().label})"
                rows = seedRows()
            }

            PanelKind.HELP -> {
                title = "How to play"
                rows = helpRows()
            }
        }

        val pw = w * 0.94f
        val rowH = 150f * u
        val gap = 10f * u
        val headerH = 110f * u
        val tabsH = if (kind == PanelKind.SHOP) 100f * u else 0f
        val footH = 120f * u
        val ph = headerH + tabsH + rows.size * (rowH + gap) + footH
        val x0 = (w - pw) / 2f
        val y0 = ((h - ph) / 2f).coerceAtLeast(10f * u)

        roundRect(c, x0, y0, x0 + pw, y0 + ph, 34f * u, 0xFF2E3B2F.toInt())
        addHit(x0, y0, x0 + pw, y0 + ph) { }
        txt(c, title, x0 + 32f * u, y0 + headerH * 0.7f, 52f * u, Color.WHITE, Paint.Align.LEFT, pw - 64f * u)

        if (kind == PanelKind.SHOP) {
            val names = listOf("Seeds", "Supplies", "Upgrades")
            val tw = (pw - 64f * u - 2f * 10f * u) / 3f
            for (i in names.indices) {
                val l = x0 + 32f * u + i * (tw + 10f * u)
                val t = y0 + headerH
                val sel = shopTab == i
                roundRect(c, l, t, l + tw, t + tabsH - 14f * u, 18f * u, if (sel) 0xFF4CAF50.toInt() else 0xFF455A4A.toInt())
                txt(c, names[i], l + tw / 2f, t + (tabsH - 14f * u) * 0.65f, 34f * u, Color.WHITE, Paint.Align.CENTER, tw - 10f * u)
                val idx = i
                addHit(l, t, l + tw, t + tabsH - 14f * u) { shopTab = idx }
            }
        }

        var ry = y0 + headerH + tabsH
        for (row in rows) {
            val rl = x0 + 20f * u
            val rr = x0 + pw - 20f * u
            roundRect(c, rl, ry, rr, ry + rowH, 24f * u, 0xFF3F5240.toInt())
            roundRect(c, rl + 16f * u, ry + (rowH - 84f * u) / 2f, rl + 100f * u, ry + (rowH + 84f * u) / 2f, 18f * u, row.color)

            val btnW = 200f * u
            val btnH = 80f * u
            val n = row.buttons.size
            val groupLeft = if (n > 0) rr - 16f * u - n * btnW - (n - 1) * 12f * u else rr
            val textX = rl + 120f * u
            val maxW = groupLeft - 16f * u - textX
            if (row.sub.isEmpty()) {
                txt(c, row.title, textX, ry + rowH * 0.6f, 40f * u, Color.WHITE, Paint.Align.LEFT, maxW)
            } else {
                txt(c, row.title, textX, ry + rowH * 0.4f, 40f * u, Color.WHITE, Paint.Align.LEFT, maxW)
                txt(c, row.sub, textX, ry + rowH * 0.74f, 30f * u, 0xFFB7D7B0.toInt(), Paint.Align.LEFT, maxW)
            }
            for (k in 0 until n) {
                val b = row.buttons[k]
                val bl = groupLeft + k * (btnW + 12f * u)
                val bt = ry + (rowH - btnH) / 2f
                roundRect(c, bl, bt, bl + btnW, bt + btnH, 20f * u, if (b.enabled) 0xFF43A047.toInt() else 0xFF78867A.toInt())
                txt(c, b.label, bl + btnW / 2f, bt + btnH * 0.66f, 34f * u, Color.WHITE, Paint.Align.CENTER, btnW - 16f * u)
                if (b.enabled) {
                    val act = b.action
                    addHit(bl, bt, bl + btnW, bt + btnH) { act() }
                }
            }
            ry += rowH + gap
        }

        // close button
        val cw = 320f * u
        val cl = x0 + (pw - cw) / 2f
        val ct = y0 + ph - footH + 16f * u
        roundRect(c, cl, ct, cl + cw, ct + 86f * u, 22f * u, 0xFFE57373.toInt())
        txt(c, "Close", cl + cw / 2f, ct + 86f * u * 0.65f, 38f * u, Color.WHITE, Paint.Align.CENTER)
        addHit(cl, ct, cl + cw, ct + 86f * u) { panel = null }
    }

    private fun shopRows(): List<Row> {
        val rows = ArrayList<Row>()
        when (shopTab) {
            0 -> {
                for (type in CropType.values()) {
                    val i = type.ordinal
                    rows.add(
                        Row(
                            "${type.label} seed  ₹${type.seedCost}",
                            "${type.growDays} days • ${type.seasonText()} • sells ₹${type.sellPrice}",
                            cropColor(type),
                            listOf(
                                Btn("Buy 1", game.coins >= type.seedCost) { game.buySeeds(i, 1) },
                                Btn("Buy 5", game.coins >= type.seedCost * 5) { game.buySeeds(i, 5) }
                            )
                        )
                    )
                }
            }

            1 -> {
                rows.add(
                    Row(
                        "Fertilizer  ₹$FERT_COST  (have ${game.fertilizer})",
                        "Grows 2x faster and gives +1 crop",
                        0xFFD7B98E.toInt(),
                        listOf(
                            Btn("Buy 1", game.coins >= FERT_COST) { game.buyFert(1) },
                            Btn("Buy 5", game.coins >= FERT_COST * 5) { game.buyFert(5) }
                        )
                    )
                )
                val cost = game.landCost()
                val left = COLS * ROWS - game.ownedCount()
                rows.add(
                    Row(
                        "Land plot  ₹$cost",
                        if (left > 0) "$left plots left (or tap a locked plot twice)" else "You own all the land",
                        0xFF8D6E63.toInt(),
                        if (left > 0) listOf(Btn("Buy", game.coins >= cost) { game.buyNextLand() }) else emptyList()
                    )
                )
            }

            else -> {
                val names = listOf("Hoe", "Watering can", "Sickle", "Fertile soil", "Bigger barn")
                for (kind in 0..4) {
                    val lv = game.level(kind)
                    val maxed = lv >= game.maxLevel(kind)
                    val title = if (kind == 4) "${names[kind]}  (Lv $lv)" else "${names[kind]}  (Lv $lv/${game.maxLevel(kind)})"
                    val sub = when (kind) {
                        0 -> "Tills and sows: ${areaText(lv)}" + if (maxed) " (max)" else " -> ${areaText(lv + 1)}"
                        1 -> "Waters and fertilizes: ${areaText(lv)}" + if (maxed) " (max)" else " -> ${areaText(lv + 1)}"
                        2 -> "Weeds and harvest: ${areaText(lv)}" + if (maxed) " (max)" else " -> ${areaText(lv + 1)}"
                        3 -> "Crops grow +${lv * 20}% faster" + if (maxed) " (max)" else " -> +${(lv + 1) * 20}%"
                        else -> "Barn holds ${game.capacity()}" + if (maxed) " (max)" else " -> ${game.capacity() + 20}"
                    }
                    val color = when (kind) {
                        0 -> 0xFF8D6E63.toInt()
                        1 -> 0xFF42A5F5.toInt()
                        2 -> 0xFFB0BEC5.toInt()
                        3 -> 0xFF6D4C41.toInt()
                        else -> 0xFFD84315.toInt()
                    }
                    val k = kind
                    val buttons = if (maxed) {
                        listOf(Btn("MAX", false) { })
                    } else {
                        val cost = game.upgradeCost(kind)
                        listOf(Btn("₹$cost", game.coins >= cost) { game.buyUpgrade(k) })
                    }
                    rows.add(Row(title, sub, color, buttons))
                }
            }
        }
        return rows
    }

    private fun areaText(level: Int): String = when (level) {
        1 -> "1 plot"
        2 -> "5 plots"
        else -> "9 plots"
    }

    private fun barnRows(): List<Row> {
        val rows = ArrayList<Row>()
        for (type in CropType.values()) {
            val i = type.ordinal
            val n = game.crops[i]
            rows.add(
                Row(
                    "${type.label}  x$n",
                    "Sells ₹${type.sellPrice} each",
                    cropColor(type),
                    listOf(
                        Btn("Sell 1", n > 0) { game.sell(i, false) },
                        Btn("Sell all", n > 0) { game.sell(i, true) }
                    )
                )
            )
        }
        return rows
    }

    private fun questRows(): List<Row> {
        val rows = ArrayList<Row>()
        for (i in game.quests.indices) {
            val q = game.quests[i]
            val sub = "${q.progress}/${q.target}  •  reward ₹${q.reward}"
            val buttons = if (q.done()) listOf(Btn("Claim", true) { game.claimQuest(i) }) else emptyList()
            rows.add(Row(q.text(), sub, if (q.done()) 0xFFFFC107.toInt() else 0xFF7CB342.toInt(), buttons))
        }
        return rows
    }

    private fun seedRows(): List<Row> {
        val rows = ArrayList<Row>()
        val s = game.season()
        for (type in CropType.values()) {
            val i = type.ordinal
            val inSeason = s in type.seasons
            val title = "${type.label}  (${game.seeds[i]} seeds)" + if (game.seedType == type) "  [selected]" else ""
            val sub = "${type.growDays} days • ${type.seasonText()}" + if (inSeason) "" else " • not in season"
            rows.add(
                Row(title, sub, cropColor(type), listOf(Btn("Use", true) {
                    game.seedType = type
                    game.tool = Tool.SEED
                    panel = null
                }))
            )
        }
        return rows
    }

    private fun helpRows(): List<Row> {
        val lines = listOf(
            "1. Hoe: tap soil to till it",
            "2. Seeds: pick a seed and tap tilled soil",
            "3. Water: crops only grow on days they are watered",
            "4. Fertilizer: grows 2x faster, +1 crop",
            "5. Sickle: pull weeds and harvest ripe crops (!)",
            "6. Barn: sell crops. Shop: seeds, tools, land"
        )
        val rows = ArrayList<Row>()
        for (l in lines) rows.add(Row(l, "", 0xFF7CB342.toInt(), emptyList()))
        return rows
    }
}
