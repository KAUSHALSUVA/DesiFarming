package com.desifarming.game

enum class Season(val label: String) {
    SUMMER("Summer"),
    MONSOON("Monsoon"),
    AUTUMN("Autumn"),
    WINTER("Winter")
}

enum class CropType(
    val label: String,
    val growDays: Int,
    val seedCost: Int,
    val sellPrice: Int,
    val seasons: Set<Season>
) {
    WHEAT("Wheat", 3, 8, 14, setOf(Season.AUTUMN, Season.WINTER)),
    GROUNDNUT("Groundnut", 4, 12, 22, setOf(Season.SUMMER, Season.MONSOON)),
    CEREALS("Cereals", 2, 5, 9, setOf(Season.SUMMER, Season.MONSOON, Season.AUTUMN)),
    SUGARCANE("Sugarcane", 6, 30, 55, setOf(Season.SUMMER, Season.MONSOON, Season.AUTUMN));

    fun seasonText(): String = seasons.joinToString("/") { it.label }
}

enum class Tool(val label: String) {
    HOE("Hoe"),
    SEED("Seeds"),
    WATER("Water"),
    FERT("Fertilizer"),
    SICKLE("Sickle")
}

class Tile {
    var owned = false
    var tilled = false
    var crop: CropType? = null
    var progress = 0f
    var watered = false
    var fertilized = false
    var weeds = false

    fun ripe(): Boolean {
        val c = crop
        return c != null && progress >= c.growDays.toFloat()
    }

    fun reset() {
        owned = false
        tilled = false
        crop = null
        progress = 0f
        watered = false
        fertilized = false
        weeds = false
    }
}

enum class QType { HARVEST, HARVEST_CROP, PLANT, WATER, WEED, EARN }

class Quest(
    val type: QType,
    val crop: CropType?,
    val target: Int,
    var progress: Int,
    val reward: Int
) {
    fun done(): Boolean = progress >= target

    fun text(): String = when (type) {
        QType.HARVEST -> "Harvest $target crops"
        QType.HARVEST_CROP -> "Harvest $target ${crop?.label ?: "crops"}"
        QType.PLANT -> "Plant $target seeds"
        QType.WATER -> "Water $target plots"
        QType.WEED -> "Pull $target weeds"
        QType.EARN -> "Earn ₹$target from sales"
    }
}
